You can place your module specific language files in this folder

